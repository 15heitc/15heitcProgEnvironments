﻿namespace Observer
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Abutton = new System.Windows.Forms.Button();
            this.Dbutton = new System.Windows.Forms.Button();
            this.Cbutton = new System.Windows.Forms.Button();
            this.Fbutton = new System.Windows.Forms.Button();
            this.Bbutton = new System.Windows.Forms.Button();
            this.submitbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(70, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(164, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "Grade Earned";
            // 
            // Abutton
            // 
            this.Abutton.Location = new System.Drawing.Point(40, 85);
            this.Abutton.Name = "Abutton";
            this.Abutton.Size = new System.Drawing.Size(93, 25);
            this.Abutton.TabIndex = 2;
            this.Abutton.Text = "A";
            this.Abutton.UseVisualStyleBackColor = true;
            this.Abutton.Click += new System.EventHandler(this.Abutton_Click);
            // 
            // Dbutton
            // 
            this.Dbutton.Location = new System.Drawing.Point(156, 150);
            this.Dbutton.Name = "Dbutton";
            this.Dbutton.Size = new System.Drawing.Size(93, 26);
            this.Dbutton.TabIndex = 3;
            this.Dbutton.Text = "D";
            this.Dbutton.UseVisualStyleBackColor = true;
            this.Dbutton.Click += new System.EventHandler(this.Dbutton_Click);
            // 
            // Cbutton
            // 
            this.Cbutton.Location = new System.Drawing.Point(39, 148);
            this.Cbutton.Name = "Cbutton";
            this.Cbutton.Size = new System.Drawing.Size(93, 26);
            this.Cbutton.TabIndex = 4;
            this.Cbutton.Text = "C";
            this.Cbutton.UseVisualStyleBackColor = true;
            this.Cbutton.Click += new System.EventHandler(this.Cbutton_Click);
            // 
            // Fbutton
            // 
            this.Fbutton.Location = new System.Drawing.Point(103, 196);
            this.Fbutton.Name = "Fbutton";
            this.Fbutton.Size = new System.Drawing.Size(93, 22);
            this.Fbutton.TabIndex = 5;
            this.Fbutton.Text = "F";
            this.Fbutton.UseVisualStyleBackColor = true;
            this.Fbutton.Click += new System.EventHandler(this.Fbutton_Click);
            // 
            // Bbutton
            // 
            this.Bbutton.Location = new System.Drawing.Point(161, 85);
            this.Bbutton.Name = "Bbutton";
            this.Bbutton.Size = new System.Drawing.Size(88, 25);
            this.Bbutton.TabIndex = 6;
            this.Bbutton.Text = "B";
            this.Bbutton.UseVisualStyleBackColor = true;
            this.Bbutton.Click += new System.EventHandler(this.Bbutton_Click);
            // 
            // submitbutton
            // 
            this.submitbutton.Location = new System.Drawing.Point(39, 238);
            this.submitbutton.Name = "submitbutton";
            this.submitbutton.Size = new System.Drawing.Size(195, 23);
            this.submitbutton.TabIndex = 7;
            this.submitbutton.Text = "Submit";
            this.submitbutton.UseVisualStyleBackColor = true;
            this.submitbutton.Click += new System.EventHandler(this.submitbutton_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(282, 289);
            this.Controls.Add(this.submitbutton);
            this.Controls.Add(this.Bbutton);
            this.Controls.Add(this.Fbutton);
            this.Controls.Add(this.Cbutton);
            this.Controls.Add(this.Dbutton);
            this.Controls.Add(this.Abutton);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Abutton;
        private System.Windows.Forms.Button Dbutton;
        private System.Windows.Forms.Button Cbutton;
        private System.Windows.Forms.Button Fbutton;
        private System.Windows.Forms.Button Bbutton;
        private System.Windows.Forms.Button submitbutton;
    }
}