﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Observer
{
    public partial class Form2 : Form
    {
        public delegate void StudentEventHandler(object sender, StudentEventArgs e);
        public int test;
       

        public event StudentEventHandler failed;
        public event StudentEventHandler aced;
        public event StudentEventHandler average;
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void gradetextBox_TextChanged(object sender, EventArgs e)
        {
        
        }

        private void Abutton_Click(object sender, EventArgs e)
        {
            test = 95;
        }

        private void Bbutton_Click(object sender, EventArgs e)
        {
            test = 85;
        }

        private void Cbutton_Click(object sender, EventArgs e)
        {
            test = 75;
        }

        private void Dbutton_Click(object sender, EventArgs e)
        {
            test = 65;
        }

        private void Fbutton_Click(object sender, EventArgs e)
        {
            test = 0;
        }

        private void submitbutton_Click(object sender, EventArgs e)
        {
            if (Student.isFailing(test))
            {
                failed(this, new StudentEventArgs(test));
            }
            if (Student.isAcing(test))
            {
                aced(this, new StudentEventArgs(test));
            }
            if (Student.isAverage(test))
            {
                average(this, new StudentEventArgs(test));
            }
            this.Close();

        }
    }

}
