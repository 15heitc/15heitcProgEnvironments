﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observer
{
    class Student
    {

        public static bool isFailing(int testScore )
        {
            if (testScore < 60)
                return true;
            return false;
        }

        public static bool isAcing(int testScore)
        {
            if (testScore >= 90)
                return true;
            return false;
        }
        public static bool isAverage(int testScore)
        {
            if (testScore > 59 && testScore < 90)
                return true;
            return false;
        }
    }
}
