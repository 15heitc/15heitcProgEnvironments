﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observer
{
    public class StudentEventArgs : EventArgs
    {
        int Score;
        public int testScore
        {
            get { return Score; }
            set { Score = value; }
        }

        public StudentEventArgs(int score)
        {
            testScore = score;
        }
    }
}
