﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Observer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void newFormbutton_Click(object sender, EventArgs e)
        {
            Form2 newF = new Form2();
            newF.Show();
            newF.failed += new Form2.StudentEventHandler(failreport);
            newF.aced += new Form2.StudentEventHandler(acereport);
            newF.average += new Form2.StudentEventHandler(averagereport);

        }
        void failreport(object sender, StudentEventArgs e)
        {
            studentlabel.Text = "The student failed. He needs to improve.";
        }
        void acereport(object sender, StudentEventArgs e)
        {
            studentlabel.Text = "The student aced it. He's got nothing to worry about.";
        }
        void averagereport(object sender, StudentEventArgs e)
        {
            studentlabel.Text = "The student has nothing to report.";
        }
        private void label1_Click(object sender, EventArgs e)
        { 

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }
    }
}
