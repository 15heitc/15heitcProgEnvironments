﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AbstractFactory
{
    public partial class Form1 : Form
    {
        Factory film;
        Movie Blockbuster;
        public Form1()
        {
            InitializeComponent();
        }
        private void actionbutton_Click(object sender, EventArgs e)
        {
            film = new ActionFactory(nametextBox.Text);
            Blockbuster = film.makeMovie();
            MessageBox.Show(Blockbuster.synopsis());
        }

        private void comedybutton_Click(object sender, EventArgs e)
        {
            film = new ComedyFactory(nametextBox.Text);
            Blockbuster = film.makeMovie();
            MessageBox.Show(Blockbuster.synopsis());
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
