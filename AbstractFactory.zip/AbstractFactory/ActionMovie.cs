﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory
{
    public class ActionMovie : Movie
    {
        string myTitle;
        string myGoodGuy;
        string myBadGuy;
        public ActionMovie(string cooltitle, string good, string bad)
        {
            myBadGuy = bad;
            myGoodGuy = good;
            myTitle = cooltitle;
        }
        public  string badGuy()
        {
          
            return myBadGuy;
        }

        public  string goodGuy()
        {
            
            return myGoodGuy;
        }

        public  string title()
        {
            return myTitle;
        }

        public override string synopsis()
        {
            return "In "+ myTitle +", the new blockbuster from Michael Bay, " + myGoodGuy  +
                 " must stop the maniac " + myBadGuy + " from blowing up the world.";
        }
    }
}
