﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory
{
    public class ComedyMovie : Movie
    {
        public string myTitle;
        public string mydirector;
        public string mystar;
        public ComedyMovie(string cooltitle, string star, string director )
        {
            myTitle = cooltitle;
            mystar = star;
            mydirector = director;
            
        }
        public string director()
        {
            return mydirector;
        }

        public string star()
        {
            return mystar;
        }

        public  string title()
        {
            return myTitle;
        }

        public override string synopsis()
        {
            return myTitle + " is the blockbuster comedy of the year starring " + 
                 mystar + " as a loveable slacker just trying to get by in this " + mydirector + " film.";
        }
    }
}
