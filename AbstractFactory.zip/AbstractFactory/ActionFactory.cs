﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory
{
    public class ActionFactory : Factory
    {
        public string name;
        public ActionFactory(string newname)
        {
            name = newname;
        }
        public override Movie makeMovie()
        {
            return new ActionMovie(name, "Max Power", "Dr. Malicious");
        }
    }
}

