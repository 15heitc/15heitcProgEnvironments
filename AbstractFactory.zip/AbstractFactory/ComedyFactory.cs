﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory
{
    public class ComedyFactory : Factory
    {
        public string name; 
        public ComedyFactory(string newname)
        {
            name = newname;
        }
        public override Movie makeMovie()
        {
            return new ComedyMovie(name, "Seth Rogen", "Judd Appatow");
        }
    }
}
