﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade
{
    class Linebackers
    {

        public bool blitz = false;
        public bool cover = false;

        public void lb_blitz()
        {
            blitz = true;
            cover = false;
        }
        
         
        public void lb_cover()
        {
            cover = true;
            blitz = false;
        }

        // Returns a string saying if it's blitzing or covering
        public string lbState()
        {
            if (cover)
            {
                return "Drop Into Coverage";
            }
            if (blitz)
            {
                return "Blitz";
            }
            else return "Unassigned";
        }
    }
}
