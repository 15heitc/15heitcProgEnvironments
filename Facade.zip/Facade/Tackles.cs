﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade
{
    class Tackles
    {
        public bool rush = false;
        public bool cover = false;
        public void dt_rush()
        {
            rush = true;
            cover = false;
        }

        public void dt_cover()
        {
            cover = true;
            rush = false;
        }
        public string dtState()
        {
            if (cover)
            {
                return "Drop Into Coverage";
            }
            if (rush)
            {
                return "Rush";
            }
            else return "Unassigned";
        }
    }
}
