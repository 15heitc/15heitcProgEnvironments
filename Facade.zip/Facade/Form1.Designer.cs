﻿namespace Facade
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.man_u_2_button = new System.Windows.Forms.Button();
            this.LineBacker_label = new System.Windows.Forms.Label();
            this.de_label = new System.Windows.Forms.Label();
            this.corner_label = new System.Windows.Forms.Label();
            this.dt_label = new System.Windows.Forms.Label();
            this.safety_label = new System.Windows.Forms.Label();
            this.lb_assign_label = new System.Windows.Forms.Label();
            this.de_assign_label = new System.Windows.Forms.Label();
            this.cb_assign_label = new System.Windows.Forms.Label();
            this.dt_assign_label = new System.Windows.Forms.Label();
            this.s_assign_label = new System.Windows.Forms.Label();
            this.engage7_button = new System.Windows.Forms.Button();
            this.c3_button = new System.Windows.Forms.Button();
            this.fire_man_button = new System.Windows.Forms.Button();
            this.dog_zone_button = new System.Windows.Forms.Button();
            this.c2sink_button = new System.Windows.Forms.Button();
            this.z_shoot_button = new System.Windows.Forms.Button();
            this.s_blitz_button = new System.Windows.Forms.Button();
            this.Header_label = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // man_u_2_button
            // 
            this.man_u_2_button.Location = new System.Drawing.Point(113, 209);
            this.man_u_2_button.Name = "man_u_2_button";
            this.man_u_2_button.Size = new System.Drawing.Size(112, 23);
            this.man_u_2_button.TabIndex = 0;
            this.man_u_2_button.Text = "2 Man Under";
            this.man_u_2_button.UseVisualStyleBackColor = true;
            this.man_u_2_button.Click += new System.EventHandler(this.man_u_2_button_Click);
            // 
            // LineBacker_label
            // 
            this.LineBacker_label.AutoSize = true;
            this.LineBacker_label.Location = new System.Drawing.Point(114, 260);
            this.LineBacker_label.Name = "LineBacker_label";
            this.LineBacker_label.Size = new System.Drawing.Size(89, 17);
            this.LineBacker_label.TabIndex = 1;
            this.LineBacker_label.Text = "Linebackers:";
            this.LineBacker_label.Click += new System.EventHandler(this.label1_Click);
            // 
            // de_label
            // 
            this.de_label.AutoSize = true;
            this.de_label.Location = new System.Drawing.Point(114, 305);
            this.de_label.Name = "de_label";
            this.de_label.Size = new System.Drawing.Size(111, 17);
            this.de_label.TabIndex = 2;
            this.de_label.Text = "Defensive Ends:";
            // 
            // corner_label
            // 
            this.corner_label.AutoSize = true;
            this.corner_label.Location = new System.Drawing.Point(114, 352);
            this.corner_label.Name = "corner_label";
            this.corner_label.Size = new System.Drawing.Size(62, 17);
            this.corner_label.TabIndex = 3;
            this.corner_label.Text = "Corners:";
            this.corner_label.Click += new System.EventHandler(this.label3_Click);
            // 
            // dt_label
            // 
            this.dt_label.AutoSize = true;
            this.dt_label.Location = new System.Drawing.Point(114, 396);
            this.dt_label.Name = "dt_label";
            this.dt_label.Size = new System.Drawing.Size(128, 17);
            this.dt_label.TabIndex = 8;
            this.dt_label.Text = "Defensive Tackles:";
            this.dt_label.Click += new System.EventHandler(this.label4_Click);
            // 
            // safety_label
            // 
            this.safety_label.AutoSize = true;
            this.safety_label.Location = new System.Drawing.Point(114, 451);
            this.safety_label.Name = "safety_label";
            this.safety_label.Size = new System.Drawing.Size(63, 17);
            this.safety_label.TabIndex = 9;
            this.safety_label.Text = "Safeties:";
            // 
            // lb_assign_label
            // 
            this.lb_assign_label.AutoSize = true;
            this.lb_assign_label.Location = new System.Drawing.Point(278, 260);
            this.lb_assign_label.Name = "lb_assign_label";
            this.lb_assign_label.Size = new System.Drawing.Size(81, 17);
            this.lb_assign_label.TabIndex = 10;
            this.lb_assign_label.Text = "unassigned";
            this.lb_assign_label.Click += new System.EventHandler(this.lb_assign_label_Click);
            // 
            // de_assign_label
            // 
            this.de_assign_label.AutoSize = true;
            this.de_assign_label.Location = new System.Drawing.Point(278, 305);
            this.de_assign_label.Name = "de_assign_label";
            this.de_assign_label.Size = new System.Drawing.Size(81, 17);
            this.de_assign_label.TabIndex = 11;
            this.de_assign_label.Text = "unassigned";
            this.de_assign_label.Click += new System.EventHandler(this.de_assign_label_Click);
            // 
            // cb_assign_label
            // 
            this.cb_assign_label.AutoSize = true;
            this.cb_assign_label.Location = new System.Drawing.Point(278, 352);
            this.cb_assign_label.Name = "cb_assign_label";
            this.cb_assign_label.Size = new System.Drawing.Size(81, 17);
            this.cb_assign_label.TabIndex = 12;
            this.cb_assign_label.Text = "unassigned";
            this.cb_assign_label.Click += new System.EventHandler(this.cb_assign_label_Click);
            // 
            // dt_assign_label
            // 
            this.dt_assign_label.AutoSize = true;
            this.dt_assign_label.Location = new System.Drawing.Point(278, 396);
            this.dt_assign_label.Name = "dt_assign_label";
            this.dt_assign_label.Size = new System.Drawing.Size(81, 17);
            this.dt_assign_label.TabIndex = 13;
            this.dt_assign_label.Text = "unassigned";
            this.dt_assign_label.Click += new System.EventHandler(this.dt_assign_label_Click);
            // 
            // s_assign_label
            // 
            this.s_assign_label.AutoSize = true;
            this.s_assign_label.Location = new System.Drawing.Point(278, 451);
            this.s_assign_label.Name = "s_assign_label";
            this.s_assign_label.Size = new System.Drawing.Size(81, 17);
            this.s_assign_label.TabIndex = 14;
            this.s_assign_label.Text = "unassigned";
            this.s_assign_label.Click += new System.EventHandler(this.s_assign_label_Click);
            // 
            // engage7_button
            // 
            this.engage7_button.Location = new System.Drawing.Point(268, 209);
            this.engage7_button.Name = "engage7_button";
            this.engage7_button.Size = new System.Drawing.Size(108, 23);
            this.engage7_button.TabIndex = 15;
            this.engage7_button.Text = "Engage 7";
            this.engage7_button.UseVisualStyleBackColor = true;
            this.engage7_button.Click += new System.EventHandler(this.engage7_button_Click);
            // 
            // c3_button
            // 
            this.c3_button.Location = new System.Drawing.Point(268, 165);
            this.c3_button.Name = "c3_button";
            this.c3_button.Size = new System.Drawing.Size(108, 23);
            this.c3_button.TabIndex = 16;
            this.c3_button.Text = "Cover 3";
            this.c3_button.UseVisualStyleBackColor = true;
            this.c3_button.Click += new System.EventHandler(this.c3_button_Click);
            // 
            // fire_man_button
            // 
            this.fire_man_button.Location = new System.Drawing.Point(113, 165);
            this.fire_man_button.Name = "fire_man_button";
            this.fire_man_button.Size = new System.Drawing.Size(112, 23);
            this.fire_man_button.TabIndex = 17;
            this.fire_man_button.Text = "Fire Man";
            this.fire_man_button.UseVisualStyleBackColor = true;
            this.fire_man_button.Click += new System.EventHandler(this.fire_man_button_Click);
            // 
            // dog_zone_button
            // 
            this.dog_zone_button.Location = new System.Drawing.Point(113, 125);
            this.dog_zone_button.Name = "dog_zone_button";
            this.dog_zone_button.Size = new System.Drawing.Size(111, 25);
            this.dog_zone_button.TabIndex = 18;
            this.dog_zone_button.Text = "CB Dogs Zone";
            this.dog_zone_button.UseVisualStyleBackColor = true;
            this.dog_zone_button.Click += new System.EventHandler(this.dog_zone_button_Click);
            // 
            // c2sink_button
            // 
            this.c2sink_button.Location = new System.Drawing.Point(268, 127);
            this.c2sink_button.Name = "c2sink_button";
            this.c2sink_button.Size = new System.Drawing.Size(108, 23);
            this.c2sink_button.TabIndex = 19;
            this.c2sink_button.Text = "Cover 2 Sink";
            this.c2sink_button.UseVisualStyleBackColor = true;
            this.c2sink_button.Click += new System.EventHandler(this.c2sink_button_Click);
            // 
            // z_shoot_button
            // 
            this.z_shoot_button.Location = new System.Drawing.Point(268, 84);
            this.z_shoot_button.Name = "z_shoot_button";
            this.z_shoot_button.Size = new System.Drawing.Size(108, 23);
            this.z_shoot_button.TabIndex = 20;
            this.z_shoot_button.Text = "Zip Shoot Gut";
            this.z_shoot_button.UseVisualStyleBackColor = true;
            this.z_shoot_button.Click += new System.EventHandler(this.z_shoot_button_Click);
            // 
            // s_blitz_button
            // 
            this.s_blitz_button.Location = new System.Drawing.Point(113, 84);
            this.s_blitz_button.Name = "s_blitz_button";
            this.s_blitz_button.Size = new System.Drawing.Size(112, 23);
            this.s_blitz_button.TabIndex = 21;
            this.s_blitz_button.Text = "Safety Blitz";
            this.s_blitz_button.UseVisualStyleBackColor = true;
            this.s_blitz_button.Click += new System.EventHandler(this.s_blitz_button_Click);
            // 
            // Header_label
            // 
            this.Header_label.AutoSize = true;
            this.Header_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Header_label.Location = new System.Drawing.Point(157, 30);
            this.Header_label.Name = "Header_label";
            this.Header_label.Size = new System.Drawing.Size(179, 29);
            this.Header_label.TabIndex = 22;
            this.Header_label.Text = "Run A Defense!";
            this.Header_label.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 505);
            this.Controls.Add(this.Header_label);
            this.Controls.Add(this.s_blitz_button);
            this.Controls.Add(this.z_shoot_button);
            this.Controls.Add(this.c2sink_button);
            this.Controls.Add(this.dog_zone_button);
            this.Controls.Add(this.fire_man_button);
            this.Controls.Add(this.c3_button);
            this.Controls.Add(this.engage7_button);
            this.Controls.Add(this.s_assign_label);
            this.Controls.Add(this.dt_assign_label);
            this.Controls.Add(this.cb_assign_label);
            this.Controls.Add(this.de_assign_label);
            this.Controls.Add(this.lb_assign_label);
            this.Controls.Add(this.safety_label);
            this.Controls.Add(this.dt_label);
            this.Controls.Add(this.corner_label);
            this.Controls.Add(this.de_label);
            this.Controls.Add(this.LineBacker_label);
            this.Controls.Add(this.man_u_2_button);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button man_u_2_button;
        private System.Windows.Forms.Label LineBacker_label;
        private System.Windows.Forms.Label de_label;
        private System.Windows.Forms.Label corner_label;
        private System.Windows.Forms.Label dt_label;
        private System.Windows.Forms.Label safety_label;
        private System.Windows.Forms.Label lb_assign_label;
        private System.Windows.Forms.Label de_assign_label;
        private System.Windows.Forms.Label cb_assign_label;
        private System.Windows.Forms.Label dt_assign_label;
        private System.Windows.Forms.Label s_assign_label;
        private System.Windows.Forms.Button engage7_button;
        private System.Windows.Forms.Button c3_button;
        private System.Windows.Forms.Button fire_man_button;
        private System.Windows.Forms.Button dog_zone_button;
        private System.Windows.Forms.Button c2sink_button;
        private System.Windows.Forms.Button z_shoot_button;
        private System.Windows.Forms.Button s_blitz_button;
        private System.Windows.Forms.Label Header_label;
    }
}

