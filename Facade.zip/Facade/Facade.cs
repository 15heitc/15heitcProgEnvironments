﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade
{
 


    class Facade
    {
        // Creates all the player objects in the Facade
        public Safeties safety = new Safeties();
        public Linebackers backers = new Linebackers();
        public Ends end = new Ends();
        public Tackles tackles = new Tackles();
        public Corners corner = new Corners();

        public Facade()
        {
           
        }

        // Runs all of the necessary functions for the Safety Blitz Defense
        public void SafetyBlitz()
        {
            safety.safety_blitz();
            backers.lb_cover();
            end.de_rush();
            tackles.dt_rush();
            corner.cb_man();
        }
        public void CBDogsZone()
        {
            safety.safety_zone3();
            backers.lb_cover();
            end.de_rush();
            tackles.dt_cover();
            corner.cb_blitz();
        }
        public void FireMan()
        {
            safety.safety_man();
            backers.lb_blitz();
            end.de_rush();
            tackles.dt_rush();
            corner.cb_man();
        }
        public void ManUnderPress2()
        {
            safety.safety_zone2();
            backers.lb_cover();
            end.de_rush();
            tackles.dt_rush();
            corner.cb_press();
        }
        public void ZipShootGut()
        {
            safety.safety_zone3();
            backers.lb_blitz();
            end.de_cover();
            tackles.dt_rush();
            corner.cb_zone3();
        }
        public void Cover2Sink()
        {
            safety.safety_zone2();
            backers.lb_cover();
            end.de_rush();
            tackles.dt_rush();
            corner.cb_zone2();
        }
        public void Cover3()
        {
            safety.safety_zone3();
            backers.lb_cover();
            end.de_rush();
            tackles.dt_rush();
            corner.cb_zone3();
        }
        public void Engage7()
        {
            safety.safety_zone3();
            backers.lb_blitz();
            end.de_rush();
            tackles.dt_rush();
            corner.cb_zone3();
        }
    }
}

