﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade
{
    class Corners
    {
        public bool man = false;
        public bool press = false;
        public bool blitz = false;
        public bool zone3 = false;
        public bool zone2 = false;

        public void cb_man()
        {
            man = true;
            press = false;
            blitz = false;
            zone3 = false;
            zone2 = false;
        }

        public void cb_press()
        {
            press = true;
            man = false;
            blitz = false;
            zone3 = false;
            zone2 = false;
        }

        public void cb_blitz()
        {
            blitz = true;
            man = false;
            zone3 = false;
            press = false;
            zone2 = false;
        }

        public void cb_zone3()
        {
            zone3 = true;
            man = false;
            press = false;
            blitz = false;
            zone2 = false;
        }
        public void cb_zone2()
        {
            zone2 = true;
            man = false;
            press = false;
            blitz = false;
            zone3 = false;
        }
        public string cornerState()
        {
            if (man)
            {
                return "Man";
            }
            if (press)
            {
                return "Press";
            }
            if (blitz)
            {
                return "Blitz";
            }
            if (zone2)
            {
                return "Zone 2";
            }
            if (zone3)
            {
                return "Zone 3";
            }
            else return "Unassigned";

        }
    }
}
