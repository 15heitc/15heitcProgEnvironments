﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade
{
    class Ends
    {
        public bool rush = false;
        public bool cover = false;

        public void de_rush()
        {
            rush = true;
            cover = false;
        }

        public void de_cover()
        {
            cover = true;
            rush = false;
        }
        public string deState()
        {
            if (cover)
            {
                return "Drop Into Coverage";
            }
            if (rush)
            {
                return "Rush";
            }
            else return "Unassigned";
        }
    }
}
