﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade
{
    class Safeties
    {
        public bool man = false;
        public bool press = false;
        public bool blitz = false;
        public bool zone3 = false;
        public bool zone2 = false;
        public bool zone1 = false;

        public void safety_man()
        {
            man = true;
            press = false;
            blitz = false;
            zone3 = false;
            zone2 = false;
            zone1 = false;
        }

        public void safety_press()
        {
            press = true;
            man = false;
            blitz = false;
            zone3 = false;
            zone2 = false;
            zone1 = false;
        }
   
        public void safety_blitz()
        {
            blitz = true;
            man = false;
            zone3 = false;
            press = false;
            zone2 = false;
            zone1 = false;
        }

        public void safety_zone3()
        {
            zone3 = true;
            man = false;
            press = false;
            blitz = false;
            zone2 = false;
            zone1 = false;
        }
        public void safety_zone2()
        {
            zone2 = true;
            man = false;
            press = false;
            blitz = false;
            zone3 = false;
            zone1 = false;
        }
        public void safety_zone1()
        {
            zone1 = true;
            man = false;
            press = false;
            blitz = false;
            zone2 = false;
            zone3 = false;
        }
        public string safety_task()
        {
            if (zone1)
            {
                return "Zone 1";
            }
            if (man)
            {
                return "Man";
            }
            if (press)
            {
                return "Press";
            }
            if (blitz)
            {
                return "Blitz";
            }
            if (zone2)
            {
                return "Zone 2";
            }
            if (zone3)
            {
                return "Zone 3";
            }
            else return "Unassigned";
        }
    }
}
