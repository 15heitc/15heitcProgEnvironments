﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Facade
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
             myFacade = new Facade();

        }

        //Changes all of the labels
        void displayPlay()
        {
            s_assign_label.Text = myFacade.safety.safety_task();
            cb_assign_label.Text = myFacade.corner.cornerState();
            dt_assign_label.Text = myFacade.tackles.dtState();
            de_assign_label.Text = myFacade.end.deState();
            lb_assign_label.Text = myFacade.backers.lbState();
        }
        //initialize the Facade
        Facade myFacade;
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void lb_assign_label_Click(object sender, EventArgs e)
        {

        }

        private void dt_assign_label_Click(object sender, EventArgs e)
        {

        }

        private void cb_assign_label_Click(object sender, EventArgs e)
        {

        }

        private void de_assign_label_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        // Runs the engage 7 defense
        private void engage7_button_Click(object sender, EventArgs e)
        {
            myFacade.Engage7();
            displayPlay();
        }

        // Runs the 2 Man Under Defense
        private void man_u_2_button_Click(object sender, EventArgs e)
        {
            myFacade.ManUnderPress2();
            displayPlay();
        }

        // Runs the Cover 3 Defense
        private void c3_button_Click(object sender, EventArgs e)
        {
            myFacade.Cover3();
            displayPlay();
        }

        // Runs the Fire Man Defense
        private void fire_man_button_Click(object sender, EventArgs e)
        {
            myFacade.FireMan();
            displayPlay();
        }

        // Runs the Cover 2 Sink 
        private void c2sink_button_Click(object sender, EventArgs e)
        {
            myFacade.Cover2Sink();
            displayPlay();
        }

        // Runs Corner Dog Zone defense
        private void dog_zone_button_Click(object sender, EventArgs e)
        {
            myFacade.CBDogsZone();
            displayPlay();

        }

        // Runs Zip Shoot Gut Defense
        private void z_shoot_button_Click(object sender, EventArgs e)
        {
            myFacade.ZipShootGut();
            displayPlay();
        }

        // Runs the Safety Blitz
        private void s_blitz_button_Click(object sender, EventArgs e)
        {
            myFacade.SafetyBlitz();
            displayPlay();

        }
       
        private void s_assign_label_Click(object sender, EventArgs e)
        {

        }
        
    }
}
