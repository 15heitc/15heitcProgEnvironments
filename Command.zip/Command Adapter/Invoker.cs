﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command_Adapter
{
    class Invoker
    {

        private Command nucommand;

        public void SetCommand(Command command)
        {
            this.nucommand = command;
        }

        public void Executer()
        {
            nucommand.Execute();
        }
    }
}
