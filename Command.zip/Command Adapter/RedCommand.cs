﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command_Adapter
{
    public class RedCommand : Command
    {
        private Receiver nuReceive;
        public RedCommand(Receiver recieve)
        {
            nuReceive = recieve;
        }

        public void SetCommand(Receiver receive)
        {
            this.nuReceive = receive;
        }
        public override void Execute()
        {
            nuReceive.makeRed();
        }

    }
}
