﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Command_Adapter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
           
        }

        private void commandbutton_Click(object sender, EventArgs e)
        {
            Receiver receive = new Receiver();
            GreenCommand draw = new GreenCommand(receive);
            Invoker invoker = new Invoker();
            invoker.SetCommand(draw);
            invoker.Executer();
            wordtextBox.ForeColor = receive.fontColor;
        }

        private void redButton_Click(object sender, EventArgs e)
        {
            Receiver receive = new Receiver();
            RedCommand draw = new RedCommand(receive);
            Invoker invoker = new Invoker();
            invoker.SetCommand(draw);
            invoker.Executer();
            wordtextBox.ForeColor = receive.fontColor;
        }

        private void custombutton_Click(object sender, EventArgs e)
        {
            Adaptee adaptee = new Adaptee();
            Adaptor adaptor = new Adaptor();
            adaptor.Request(Int32.Parse(wordtextBox.Text));
    

          //  wordtextBox.ForeColor = Color.FromName(wordtextBox.Text);
            wordtextBox.ForeColor = adaptor.fontcolor;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
