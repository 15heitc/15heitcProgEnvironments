﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Command_Adapter
{
    public abstract class Target
    {
        public  Color font;
      public abstract void Request(int number);
    }
}
