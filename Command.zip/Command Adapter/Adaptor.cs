﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Command_Adapter
{
    public class Adaptor : Target
    {
        public  Color fontcolor;
      public override void Request(int adaptee)
        {
            switch (adaptee)
            {
                case 1:
                    fontcolor = System.Drawing.Color.Blue;
                    break;
                case 2:
                    fontcolor = System.Drawing.Color.Orange;
                    break;
                case 3:
                    fontcolor = System.Drawing.Color.Purple;
                    break;
                case 4:
                    fontcolor = System.Drawing.Color.Yellow;
                    break;
                case 5:
                    fontcolor = System.Drawing.Color.Brown;
                    break;
                default:
                    fontcolor = System.Drawing.Color.Black;
                    break;

            }
        }
    }
}
