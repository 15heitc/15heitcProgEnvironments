/**
 * Created by PhpStorm.
 * User: 15heitc
 * Date: 12/8/2016
 * Time: 10:19 PM
 */

<div id="Manage" ?>

    <hr>
    <h3>Episode</h3>
    <form action="../wp-content/plugins/Fan-Favorites/Add.php" method="post">
        <div>
            <h3>Episode Number:</h3>
            <input type='number' name='idEp'>
            <h3>Title:</h3>
            <input type='text' name='name'>
            <h3>Season:</h3>
            <input type='number' name='season'>
            <h3>Show:</h3>
            <input type='number' name='idshow'>
            <input type="submit" value="Insert New Episode">
        </div>
    </form>
    <hr>
</div>