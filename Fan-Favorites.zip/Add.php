
<?php
include_once('episode.php');
foreach(array_keys($_POST) as $key)
    echo "<p>" . $key . " => " . $_POST[$key] . "</p>";
$Product = new episode($_POST['idEp'],$_POST['name'], $_POST['season'], $_POST['show']);
$Product->insert('fav_episodesss');
?>
