/**
 * Created by PhpStorm.
 * User: 15heitc
 * Date: 12/8/2016
 * Time: 10:26 PM
 */
<div class="wrap">
  <p>My Plugin Database Table Prefix</p>
  <input type="text" value="mp_">
</div>