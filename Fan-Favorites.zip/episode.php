<?php

if (file_exists('../../../wp-config.php' ))
{
    include_once('../../../wp-config.php' );
}
else if (file_exists('./wp-config.php'))
{
    include_once('./wp-config.php');
}
class Episode{
    public $name;
    public $season;
    public $idEp;
    public $show;

    public function __construct($idEp, $name,$season,$show){
        $this->idEp = $idEp;
        $this->name = $name;
        $this->season = $season;
        $this->show = $show;
    }


    public function insert($table_name)
    {
        global $wpdb;
        $insert = "insert into " . $table_name . "(idEp, name, season, show)" .
            "values ( " .
            "'" . $this->idEp . "'," .
            "'" . $this->name . "'," .
            "'" . $this->season . "'," .
            $this->show .
            ")" .
            ";";
        $wpdb->query($insert);
    }

    public static function get_all_products($table_name)
    {
        global $wpdb;
        $select = "select * from " . $table_name . ";";
        $all_products = $wpdb->get_results($select);
        return $all_products;

    }
    public function display($eptable, $favtable)
    {
        global $wpdb;
        $crossref = "select * from ". $eptable. ";";
        $topten = $wpdb->get_results($crossref);
        return $topten;
    }
}