<?php
/*
Plugin Name: Fan-Favorites
Plugin URI:  http://URI_Of_Page_Describing_Plugin_and_Updates
Description: A plugin used to make a top ten list of episodes
Version:     1.0
Author:     Cory Heitkamp
Author URI:  http://heitkamponline.com
License:     GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Domain Path: /languages
Text Domain:
*/
#region Regions
#region Administrative Page for
add_action( 'admin_menu', 'fav_menu' );
function fav_menu() {
    add_menu_page( 'Fan Favorites', 'Fan Favorites', 'manage_options', 'fav_menu', 'fav_user_options' );
    add_submenu_page( 'fav_menu', "Fav Episode Options", "Fav Episode Menu", 'manage_options', 'fav_episode_menu', 'fav_episode_options' );
}
/**
 *
 */
function fav_options() {
    if ( !current_user_can( 'manage_options' ) )  {
        wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
    }
    include( __DIR__ . '/favOptions.php' );
}
function fav_episode_options()
{
    if ( !current_user_can( 'manage_options' ) )  {
        wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
    }
    include( __DIR__ . '/favManage.php' );
}

register_activation_hook( __FILE__, FAN_FAVORITE_Activate );
$fav_prefix_prefix = 'fav_';
function FAN_FAVORITE_Activate(){
    global $fav_prefix;
    $fav_prefix = 'fav_';
    makeTables();
}
function makeTables()
{

    CreateUserTable();
    CreateEpisodeTable();
    CreateFavoritesTable();
    CreateShowTable();

}

function CreateUserTable() {
    global $fav_prefix;
    $schema = "idEpisode int(11) NOT NULL,
                name varchar(90)NOT NULL,
                 PRIMARY KEY (idUser)";
    CreateTable($fav_prefix.'please',$schema);

}
function CreateFavoritesTable() {
    global $fav_prefix;
    $schema = "idFavorites int NOT NULL,
                idEpisode int NOT NULL,
                name varchar(90) NOT NULL,
                idShow int NOT NULL,
                idUser int NOT NULL,
                 PRIMARY KEY (idEpisode)";
    CreateTable($fav_prefix.'epsodes',$schema);

}

global $fav_prefix;
$schema = "idE int NOT NULL,
               name varchar(90) NOT NULL,
               season int NOT NULL,
               show int NOT NULL,
                PRIMARY KEY (idEp)";
CreateTable($fav_prefix.'epis',$schema);

function CreateEpisodeTable() {
    global $fav_prefix;
    $schema = "idEp int NOT NULL,
                name varchar(90) NOT NULL,
                season int NOT NULL,
                idshow int NOT NULL,
                 PRIMARY KEY (idEp)";
    CreateTable($fav_prefix.'episode',$schema);

}
function CreateShowTable() {
    global $fav_prefix;
    $schema = "idUser int(11) NOT NULL,
                name varchar(90)NOT NULL,
                 PRIMARY KEY (idUser)";
    CreateTable($fav_prefix.'show',$schema);

}

/*
 dbDelta was not acceptable.  $wpdb->query($sql) works just fine and is not picky about the structure of $sql
*/
function CreateTable($name, $schema){
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE $name (". $schema . ") $charset_collate;";
    $wpdb->query($sql);

}
