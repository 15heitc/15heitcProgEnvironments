﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Last_Try
{
    // Creates a public class inheriting from the iterator class
    public class SuperBowlIterator : Iterator
    {
    Aggregate aggregate;
    int CurrIndex = 0;

    // initializes an instance of the Team class     
    Team nfl;

    // initializes an instance of the iterator class
    Iterator iterator;

    public SuperBowlIterator(Aggregate agg)
    {
        aggregate = agg;
    }


    public override Team First()
    {

        nfl = new Team();
        CurrIndex = 0;
            //starts at the first address
            //checks if they've won a Super Bowl.
        if (nfl.getPlayoffs() == true)
        {
            return CurrentItem();
        }
        return null;
    }

    // goes from object to object in the list
    public override Team Next()
    {

        CurrIndex++;
        //checks if they've won a Super Bowl
        if (nfl.getSuperBowl() == true)
        {
            return CurrentItem();
        }
        else return null;
    }

    // checks if the every object has been iterated through     
    public override bool IsDone()
    {
        if (CurrIndex > 10) { return true; }
        else return false;
    }

    public override Team CurrentItem()
    {
        //creates an iterator     
        iterator = aggregate.createIterator();

        //checks if the team has won a Super Bowl     
        if (iterator.CurrentItem().getSuperBowl())
        {
            if (IsDone())
                return null;
            // returns the team object
            return aggregate.elements[CurrIndex];
        }
        return null;
    }
}
}

