﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Last_Try
{
    public class PlayoffIterator : Iterator
    {
        Aggregate aggregate;

        //sets initial index to 0
        int CurrIndex = 0;
        Team nfl;
        Iterator iterator;

        public PlayoffIterator(Aggregate agg)
        {
            aggregate = agg;
        }

        // inherited from iterator, looks at first object
        public override Team First()
        {
            nfl = new Team();
            CurrIndex = 0;

            //checks if they've made playoffs, and returns the item they have
            if (nfl.getPlayoffs() == true)
            {
                return CurrentItem();
            }
            return null;
            }

        // goes through the objects
        public override Team Next()
        {
            // adds to the index and moves to the the next object
            CurrIndex++;

            if (nfl.getPlayoffs() == true)
            {
                return CurrentItem();
            }
            else return null;
        }

        // checks whether iteration should continue or stop
        public override bool IsDone()
        {
            if (CurrIndex > 10 ) { return true; }
            else return false;
        }

        // used through the other functions
        // returns the object if they've made the playoffs
        public override Team CurrentItem()
        {
            iterator = aggregate.createIterator();
            if (iterator.CurrentItem().getPlayoffs())
            {
                if (IsDone())
                    return null;
                return aggregate.elements[CurrIndex];
            }
            return null;
        }
    }
}

