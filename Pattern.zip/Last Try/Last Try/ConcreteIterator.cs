﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Last_Try
{
    public class ConcreteIterator : Iterator
    {

        Aggregate aggregate;
        int CurrIndex = 0;

        // defines a concrete iterator
        public ConcreteIterator(Aggregate agg)
        {
            aggregate = agg;
        }

        // starts at the last team on the list
        public override Team First()
        {
            CurrIndex = 10;
            return CurrentItem();
        }

        // goes through the list in reverse order
        public override Team Next()
        {
            CurrIndex--;
            return CurrentItem();
        }

        //checks if the end of the list has been reached
        public override bool IsDone()
        {
            if (CurrIndex < 0) { return true; }
            else return false;
        }

        // returns the team
        public override Team CurrentItem()
        {
            if (IsDone())
                return null;     
            return aggregate.elements[CurrIndex];
        }
    }
}
