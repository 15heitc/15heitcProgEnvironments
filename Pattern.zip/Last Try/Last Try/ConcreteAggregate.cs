﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Last_Try
{
    public class ConcreteAggregate : Aggregate // this is the ConcreteAggregate class
    {
       
        public ConcreteAggregate()
        {
            //creates the list that holds the Teams
            elements = new List<Team>();
        }

        //creates a concrete iterator
        public override Iterator createIterator()
        {
            return new ConcreteIterator(this);
        }

        //creates a playoff iterator
        public override Iterator createPlayoffIterator()
        {
            return new PlayoffIterator(this);
                }

        //creates a Super Bowl Iterator
        public override Iterator createSuperBowlIterator()
        {
            return new SuperBowlIterator(this);
        }
    }

}
