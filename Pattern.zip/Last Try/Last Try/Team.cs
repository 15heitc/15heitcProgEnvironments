﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Last_Try
{
    public class Team
    {
        //creates the fields for the NFL teams
        string name;
        int wins;
        bool playoffs;
        bool noSuperBowl;

        // allows the Team to be made by entering in the fields
        public Team(string Name, int Wins, bool Playoffs, bool SuperBowl)
        {
            name = Name;
            wins = Wins;
            playoffs = Playoffs;
            noSuperBowl = SuperBowl;
        }
        //allows a team to be created without fields
        public Team()
        {

        }

        //returns the team name
        public string getName()
        {
            return name;
        }

        //returns the number of team wins
        public string getWins()
        {
            return name;
        }

        // returns if they were in last year's playoffs
        public bool getPlayoffs()
        {
            return playoffs;
        }

        //returns if they've ever won a Super Bowl
        public bool getSuperBowl()
        {
            return noSuperBowl;
        }

    }
}
