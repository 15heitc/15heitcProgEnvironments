﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Composite
{
    public class Composite : Component
    {
        string coursename;
        string display;
        string current;
        List <Component> children = new List<Component>();
        public override void add(Component course)
        {
            children.Add(course);
        }

        public override void remove(Component course)
        {
            children.Remove(course);

        }

        public override string Display(int depth)
        {
            foreach (Component component in children)
            {
                if(coursename == "Programming")
                {
                    display = "Programming :"+ System.Environment.NewLine;
                }
               display += component.Display(depth+2);
            }
            current = display;
            display = "";
            return current;
            
        }

        public Composite(string name)
        {
            coursename = name;
        }
    }
}
