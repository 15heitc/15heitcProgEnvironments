﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Composite
{
   public class Leaf: Component
    {
        string coursename;
        int hours;
        Composite comp;

        public override void add(Component course)
        {
            throw new NotImplementedException();
        }

        public Leaf(string name, int coursehours)
        {
            coursename = name;
            hours = coursehours;
        }

        public override void remove(Component course)
        {
            throw new NotImplementedException();
        }
        
        public override string Display(int depth)
        {
           String word = new String('-', depth) + coursename+ " "+ hours +" credit hours " + System.Environment.NewLine;
            return word;
        }
    }
}
