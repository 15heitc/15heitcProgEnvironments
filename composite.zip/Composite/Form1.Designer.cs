﻿namespace Composite
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.coursebutton = new System.Windows.Forms.Button();
            this.coursetextBox = new System.Windows.Forms.TextBox();
            this.programmingbutton = new System.Windows.Forms.Button();
            this.Calcbutton = new System.Windows.Forms.Button();
            this.writingbutton = new System.Windows.Forms.Button();
            this.hourlabel = new System.Windows.Forms.Label();
            this.calcdeletebutton = new System.Windows.Forms.Button();
            this.biodeletebutton = new System.Windows.Forms.Button();
            this.progdeletebutton = new System.Windows.Forms.Button();
            this.seminardeletebutton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // coursebutton
            // 
            this.coursebutton.Location = new System.Drawing.Point(42, 58);
            this.coursebutton.Name = "coursebutton";
            this.coursebutton.Size = new System.Drawing.Size(75, 36);
            this.coursebutton.TabIndex = 0;
            this.coursebutton.Text = "Biology";
            this.coursebutton.UseVisualStyleBackColor = true;
            this.coursebutton.Click += new System.EventHandler(this.coursebutton_Click);
            // 
            // coursetextBox
            // 
            this.coursetextBox.Location = new System.Drawing.Point(42, 166);
            this.coursetextBox.Multiline = true;
            this.coursetextBox.Name = "coursetextBox";
            this.coursetextBox.Size = new System.Drawing.Size(287, 246);
            this.coursetextBox.TabIndex = 1;
            this.coursetextBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // programmingbutton
            // 
            this.programmingbutton.Location = new System.Drawing.Point(283, 60);
            this.programmingbutton.Name = "programmingbutton";
            this.programmingbutton.Size = new System.Drawing.Size(89, 28);
            this.programmingbutton.TabIndex = 2;
            this.programmingbutton.Text = "Programing";
            this.programmingbutton.UseVisualStyleBackColor = true;
            this.programmingbutton.Click += new System.EventHandler(this.programmingbutton_Click);
            // 
            // Calcbutton
            // 
            this.Calcbutton.Location = new System.Drawing.Point(42, 109);
            this.Calcbutton.Name = "Calcbutton";
            this.Calcbutton.Size = new System.Drawing.Size(75, 23);
            this.Calcbutton.TabIndex = 3;
            this.Calcbutton.Text = "Calculus";
            this.Calcbutton.UseVisualStyleBackColor = true;
            this.Calcbutton.Click += new System.EventHandler(this.Calcbutton_Click);
            // 
            // writingbutton
            // 
            this.writingbutton.Location = new System.Drawing.Point(254, 109);
            this.writingbutton.Name = "writingbutton";
            this.writingbutton.Size = new System.Drawing.Size(143, 23);
            this.writingbutton.TabIndex = 4;
            this.writingbutton.Text = "Writing Seminar";
            this.writingbutton.UseVisualStyleBackColor = true;
            this.writingbutton.Click += new System.EventHandler(this.writingbutton_Click);
            // 
            // hourlabel
            // 
            this.hourlabel.AutoSize = true;
            this.hourlabel.Location = new System.Drawing.Point(126, 146);
            this.hourlabel.Name = "hourlabel";
            this.hourlabel.Size = new System.Drawing.Size(114, 17);
            this.hourlabel.TabIndex = 6;
            this.hourlabel.Text = "Schedule Hours-";
            // 
            // calcdeletebutton
            // 
            this.calcdeletebutton.Location = new System.Drawing.Point(129, 109);
            this.calcdeletebutton.Name = "calcdeletebutton";
            this.calcdeletebutton.Size = new System.Drawing.Size(75, 23);
            this.calcdeletebutton.TabIndex = 7;
            this.calcdeletebutton.Text = "Delete";
            this.calcdeletebutton.UseVisualStyleBackColor = true;
            this.calcdeletebutton.Click += new System.EventHandler(this.calcdeletebutton_Click);
            // 
            // biodeletebutton
            // 
            this.biodeletebutton.Location = new System.Drawing.Point(127, 65);
            this.biodeletebutton.Name = "biodeletebutton";
            this.biodeletebutton.Size = new System.Drawing.Size(75, 23);
            this.biodeletebutton.TabIndex = 8;
            this.biodeletebutton.Text = "Delete";
            this.biodeletebutton.UseVisualStyleBackColor = true;
            this.biodeletebutton.Click += new System.EventHandler(this.biodeletebutton_Click);
            // 
            // progdeletebutton
            // 
            this.progdeletebutton.Location = new System.Drawing.Point(378, 63);
            this.progdeletebutton.Name = "progdeletebutton";
            this.progdeletebutton.Size = new System.Drawing.Size(75, 23);
            this.progdeletebutton.TabIndex = 9;
            this.progdeletebutton.Text = "Delete";
            this.progdeletebutton.UseVisualStyleBackColor = true;
            this.progdeletebutton.Click += new System.EventHandler(this.progdeletebutton_Click);
            // 
            // seminardeletebutton
            // 
            this.seminardeletebutton.Location = new System.Drawing.Point(403, 109);
            this.seminardeletebutton.Name = "seminardeletebutton";
            this.seminardeletebutton.Size = new System.Drawing.Size(75, 23);
            this.seminardeletebutton.TabIndex = 10;
            this.seminardeletebutton.Text = "Delete";
            this.seminardeletebutton.UseVisualStyleBackColor = true;
            this.seminardeletebutton.Click += new System.EventHandler(this.seminardeletebutton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(122, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(264, 29);
            this.label1.TabIndex = 11;
            this.label1.Text = "Schedule Your Classes";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(492, 413);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.seminardeletebutton);
            this.Controls.Add(this.progdeletebutton);
            this.Controls.Add(this.biodeletebutton);
            this.Controls.Add(this.calcdeletebutton);
            this.Controls.Add(this.hourlabel);
            this.Controls.Add(this.writingbutton);
            this.Controls.Add(this.Calcbutton);
            this.Controls.Add(this.programmingbutton);
            this.Controls.Add(this.coursetextBox);
            this.Controls.Add(this.coursebutton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button coursebutton;
        private System.Windows.Forms.TextBox coursetextBox;
        private System.Windows.Forms.Button programmingbutton;
        private System.Windows.Forms.Button Calcbutton;
        private System.Windows.Forms.Button writingbutton;
        private System.Windows.Forms.Label hourlabel;
        private System.Windows.Forms.Button calcdeletebutton;
        private System.Windows.Forms.Button biodeletebutton;
        private System.Windows.Forms.Button progdeletebutton;
        private System.Windows.Forms.Button seminardeletebutton;
        private System.Windows.Forms.Label label1;
    }
}

