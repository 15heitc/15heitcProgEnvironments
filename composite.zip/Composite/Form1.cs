﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Composite
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int hours= 0;
        Composite schedule = new Composite("Schedule");
        Composite programming = new Composite("Programming");
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void coursebutton_Click(object sender, EventArgs e)
        {
            schedule.add(new Leaf("Biology",3));

            coursetextBox.Text = schedule.Display(1);
            hours += 3;
            hourlabel.Text = "Schedule Hours- " + hours;
        }

        private void Calcbutton_Click(object sender, EventArgs e)
        {
            schedule.add(new Leaf("Calculus", 4));
            hours += 4;
            coursetextBox.Text = schedule.Display(1);
            hourlabel.Text = "Schedule Hours- " + hours;

        }

        private void programmingbutton_Click(object sender, EventArgs e)
        {
            programming.add(new Leaf("Lecture", 3));
            hours += 3;
            programming.add(new Leaf("Lab", 1));
            hours += 1;
            schedule.add(programming);
            coursetextBox.Text = schedule.Display(1);
            hourlabel.Text = "Schedule Hours- " + hours;
        }

        private void writingbutton_Click(object sender, EventArgs e)
        {
            schedule.add(new Leaf("Writing Seminar", 3));
            hours += 3;
            coursetextBox.Text = schedule.Display(1);   
            
            hourlabel.Text = "Schedule Hours- " + hours;
        }

        private void biodeletebutton_Click(object sender, EventArgs e)
        {
            schedule.remove(programming);
            hours -= 3;
            coursetextBox.Text = schedule.Display(1);
            hourlabel.Text = "Schedule Hours- " + hours;

        }

        private void calcdeletebutton_Click(object sender, EventArgs e)
        {
            hours -= 4;
        }

        private void progdeletebutton_Click(object sender, EventArgs e)
        {
            schedule.remove(programming);
            hours -= 4;
            coursetextBox.Text = schedule.Display(1);
            hourlabel.Text = "Schedule Hours- " + hours;
        }

        private void seminardeletebutton_Click(object sender, EventArgs e)
        {
            hours -= 4;
        }
    }
}
