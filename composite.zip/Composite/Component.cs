﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Composite
{
   public abstract class Component
    {
        string classname;
        public abstract string Display(int depth);
        public abstract void add(Component course);
        public abstract void remove(Component course);
    }
}
